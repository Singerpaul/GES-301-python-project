
# GSE301 Python Project – Student Academic Performance System

This repository contains the full Python implementation for the GSE301 Data Science course project.

## Features
- Student data storage using lists, dictionaries, tuples, and sets
- Score-to-grade converter using IF/ELIF/ELSE and MATCH CASE
- Input validation with TRY/EXCEPT
- List slicing and set operations
- Menu-driven console system
- Graduation eligibility checker
- Top performer finder

## Files
- `student_analysis.py` – Main Python script
- `README.md` – Project documentation

## How to Run
```bash
python student_analysis.py
```

## Author
**Soladoye Paul**
