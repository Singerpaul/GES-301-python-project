
# Student Academic Performance Analysis System
# GSE301 Project
# Author: Soladoye Paul

# ----------------------------
# PART 1: DATA COLLECTION
# ----------------------------

# Sample student profiles
students = [
    {
        "name": "Rasheed Fatia",
        "matric": "23/60AC389",
        "age": 21,
        "cgpa": 4.81,
        "is_active": True,
        "courses": ["Data Science", "Statistics"],
        "grades": {"Data Science": "A", "Statistics": "B"}
    },
    {
        "name": "Yusuf Adeoye",
        "matric": "23/70JC093",
        "age": 22,
        "cgpa": 3.45,
        "is_active": True,
        "courses": ["Python", "Algorithms"],
        "grades": {"Python": "B", "Algorithms": "A"}
    },
    {
        "name": "Moses Oyedele",
        "matric": "23/15EE402",
        "age": 20,
        "cgpa": 3.90,
        "is_active": False,
        "courses": ["Python", "Networking"],
        "grades": {"Python": "A", "Networking": "C"}
    }
]

# Set of unique department courses
unique_courses = {"Python", "Data Science", "Statistics", "Algorithms", "Networking"}

# Tuple: department info
department_info = ("Computer Science", "Faculty of Technology", 2025)

# ----------------------------
# PART 2: PROCESSING & LOGIC
# ----------------------------

def score_to_grade(score):
    """Return letter grade from score and feedback using MATCH CASE."""
    if score >= 70:
        grade = "A"
    elif score >= 60:
        grade = "B"
    elif score >= 50:
        grade = "C"
    elif score >= 45:
        grade = "D"
    elif score >= 40:
        grade = "E"
    else:
        grade = "F"

    match grade:
        case "A":
            print("Excellent performance!")
        case "B":
            print("Very good work.")
        case "C":
            print("Good effort.")
        case "D":
            print("Fair performance.")
        case "E":
            print("Weak but passable.")
        case "F":
            print("Poor. Improvement needed.")

    return grade

def validate_user_inputs(age_str, cgpa_str):
    """Validate and convert user inputs using TRY EXCEPT."""
    try:
        age = int(age_str)
        cgpa = float(cgpa_str)

        if not (16 <= age <= 40):
            raise ValueError("Age must be between 16 and 40.")

        if not (0.0 <= cgpa <= 5.0):
            raise ValueError("CGPA must be between 0.0 and 5.0.")

        return age, cgpa
    except Exception as e:
        print("Input Error:", e)
        return None, None


# ----------------------------
# PART 3: ANALYSIS & REPORTING
# ----------------------------

def list_operations():
    scores = [45, 70, 88, 92, 50, 63, 77, 85, 90, 55]
    print("Top 3:", scores[:3])
    print("Last 5:", scores[-5:])
    print("Every other score:", scores[::2])

def set_operations():
    set_pass = {"Rasheed Fatia", "Yusuf Adeoye", "Moses Oyedele"}
    set_merit = {"Rasheed Fatia", "Moses Oyedele"}

    print("Passed & Merit:", set_pass & set_merit)
    print("All distinct:", set_pass | set_merit)
    print("Passed only (no merit):", set_pass - set_merit)


# ----------------------------
# PART 4: MENU SYSTEM
# ----------------------------

def find_top_performer():
    return max(students, key=lambda x: x["cgpa"])

def check_graduation(student):
    """Check graduation eligibility."""
    if student["cgpa"] >= 2.5 and student["is_active"] and len(student["courses"]) > 0:
        return True, f"{student['name']} is eligible for graduation."
    return False, f"{student['name']} is NOT eligible for graduation."

def add_student():
    name = input("Enter name: ")
    matric = input("Enter matric number: ")
    age_str = input("Enter age: ")
    cgpa_str = input("Enter CGPA: ")
    is_active_str = input("Is active? (yes/no): ")
    courses_str = input("Enter courses (comma-separated): ")

    age, cgpa = validate_user_inputs(age_str, cgpa_str)
    if age is None:
        print("Failed to add student due to invalid inputs.")
        return

    is_active = is_active_str.lower() == "yes"
    courses = [c.strip() for c in courses_str.split(",")]

    students.append({
        "name": name,
        "matric": matric,
        "age": age,
        "cgpa": cgpa,
        "is_active": is_active,
        "courses": courses,
        "grades": {}
    })

    print("Student added successfully!")


def menu():
    while True:
        print("\n=== Student Academic Performance System ===")
        print("1. View all students")
        print("2. Add new student")
        print("3. Check eligibility for graduation")
        print("4. Find top performer")
        print("5. Exit")

        choice = input("Enter your choice: ")

        match choice:
            case "1":
                for s in students:
                    print("-", s["name"])
            case "2":
                add_student()
            case "3":
                name = input("Enter student name: ")
                found = next((s for s in students if s["name"].lower() == name.lower()), None)
                if found:
                    print(check_graduation(found)[1])
                else:
                    print("Student not found.")
            case "4":
                top = find_top_performer()
                print("Top Performer:", top["name"], "CGPA:", top["cgpa"])
            case "5":
                print("Goodbye!")
                break
            case _:
                print("Invalid choice.")


if __name__ == "__main__":
    print("System loaded. Profiles available:", len(students))
    # menu()   # Uncomment when running interactively
